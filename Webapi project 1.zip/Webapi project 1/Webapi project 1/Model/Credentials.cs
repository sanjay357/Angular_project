﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Webapi_project_1.Model
{
    public class Credentials
    {
        public string username { get; set; }
        public string pwd { get; set; }
    }
}
